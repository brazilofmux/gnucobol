/*
   Copyright (C) 2002-2012, 2019, 2022, 2025 Free Software Foundation, Inc.
   Written by Keisuke Nishida, Roger While, Simon Sobisch

   This file is part of GnuCOBOL.

   The GnuCOBOL runtime library is free software: you can redistribute it
   and/or modify it under the terms of the GNU Lesser General Public License
   as published by the Free Software Foundation, either version 3 of the
   License, or (at your option) any later version.

   GnuCOBOL is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with GnuCOBOL.  If not, see <https://www.gnu.org/licenses/>.
*/


#ifndef COB_LIBCOB_H
#define COB_LIBCOB_H

#ifdef __cplusplus
extern "C" {
#endif

/* note: this header is always below this (system) header file,
   and we want it toi be used before the installed one */
#include "libcob/common.h"	/* IWYU pragma: export */

#ifdef __cplusplus
}
#endif

#endif /* COB_LIBCOB_H_ */
