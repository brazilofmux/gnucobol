void dummymacfix(void);
void
dummymacfix ()
{
}
