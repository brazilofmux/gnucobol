/* A Bison parser, made by GNU Bison 3.5.1.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2020 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* Undocumented macros, especially those whose name start with YY_,
   are private implementation details.  Do not rely on them.  */

#ifndef YY_PP_PPPARSE_H_INCLUDED
# define YY_PP_PPPARSE_H_INCLUDED
/* Debug traces.  */
#ifndef PPDEBUG
# if defined YYDEBUG
#if YYDEBUG
#   define PPDEBUG 1
#  else
#   define PPDEBUG 0
#  endif
# else /* ! defined YYDEBUG */
#  define PPDEBUG 0
# endif /* ! defined YYDEBUG */
#endif  /* ! defined PPDEBUG */
#if PPDEBUG
extern int ppdebug;
#endif

/* Token type.  */
#ifndef PPTOKENTYPE
# define PPTOKENTYPE
  enum pptokentype
  {
    TOKEN_EOF = 0,
    ALSO = 258,
    BY = 259,
    COPY = 260,
    EQEQ = 261,
    IN = 262,
    LAST = 263,
    LEADING = 264,
    OF = 265,
    OFF = 266,
    PRINTING = 267,
    REPLACE = 268,
    REPLACING = 269,
    SUPPRESS = 270,
    TRAILING = 271,
    DOT = 272,
    GARBAGE = 273,
    LISTING_DIRECTIVE = 274,
    LISTING_STATEMENT = 275,
    TITLE_STATEMENT = 276,
    COBOL_WORDS_DIRECTIVE = 277,
    EQUATE = 278,
    UNDEFINE = 279,
    SUBSTITUTE = 280,
    RESERVE = 281,
    CONTROL_STATEMENT = 282,
    SOURCE = 283,
    NOSOURCE = 284,
    LIST = 285,
    NOLIST = 286,
    MAP = 287,
    NOMAP = 288,
    LEAP_SECOND_DIRECTIVE = 289,
    SOURCE_DIRECTIVE = 290,
    FORMAT = 291,
    IS = 292,
    FIXED = 293,
    FREE = 294,
    VARIABLE = 295,
    CALL_DIRECTIVE = 296,
    COBOL = 297,
    TOK_EXTERN = 298,
    STDCALL = 299,
    STATIC = 300,
    DEFINE_DIRECTIVE = 301,
    AS = 302,
    PARAMETER = 303,
    OVERRIDE = 304,
    REFMOD_DIRECTIVE = 305,
    SET_DIRECTIVE = 306,
    ADDRSV = 307,
    ADDSYN = 308,
    ASSIGN = 309,
    CALLFH = 310,
    XFD = 311,
    COMP1 = 312,
    CONSTANT = 313,
    DPC_IN_DATA = 314,
    FOLDCOPYNAME = 315,
    KEYCOMPRESS = 316,
    NOKEYCOMPRESS = 317,
    MAKESYN = 318,
    NODPC_IN_DATA = 319,
    NOFOLDCOPYNAME = 320,
    NOODOSLIDE = 321,
    ODOSLIDE = 322,
    REMOVE = 323,
    SOURCEFORMAT = 324,
    SPZERO = 325,
    SSRANGE = 326,
    IF_DIRECTIVE = 327,
    ELSE_DIRECTIVE = 328,
    ENDIF_DIRECTIVE = 329,
    ELIF_DIRECTIVE = 330,
    GE = 331,
    LE = 332,
    LT = 333,
    GT = 334,
    EQ = 335,
    NE = 336,
    NOT = 337,
    THAN = 338,
    TO = 339,
    OR = 340,
    EQUAL = 341,
    GREATER = 342,
    LESS = 343,
    SET = 344,
    DEFINED = 345,
    TURN_DIRECTIVE = 346,
    ON = 347,
    CHECKING = 348,
    WITH = 349,
    LOCATION = 350,
    TERMINATOR = 351,
    TOKEN = 352,
    TEXT_NAME = 353,
    VARIABLE_NAME = 354,
    LITERAL = 355
  };
#endif

/* Value type.  */
#if ! defined PPSTYPE && ! defined PPSTYPE_IS_DECLARED
union PPSTYPE
{
#line 521 "ppparse.y"

	char			*s;
	struct cb_text_list	*l;
	struct cb_replace_list	*r;
	struct cb_define_struct	*ds;
	unsigned int		ui;
	int			si;

#line 176 "ppparse.h"

};
typedef union PPSTYPE PPSTYPE;
# define PPSTYPE_IS_TRIVIAL 1
# define PPSTYPE_IS_DECLARED 1
#endif


extern PPSTYPE pplval;

int ppparse (void);

#endif /* !YY_PP_PPPARSE_H_INCLUDED  */
